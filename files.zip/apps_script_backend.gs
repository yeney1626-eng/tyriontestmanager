var ENTRIES_SHEET_NAME = 'Entries';          // set to your actual entries tab name if different
var WEEKLY_SHEET_NAME = 'Weekly Running Summary';

var DATE_COL = 4;   // column D — Date (Entries tab)
var USER_COL = 2;   // column B — User (Entries tab)
var WB_COL = 3;      // column C — WB (Entries tab)
var HEADER_ROWS = 1;

var WEEKLY_DATE_COL = 2; // column B — Week Beginning (Weekly Summary tab)
var WEEKLY_USER_COL = 1; // column A — User (Weekly Summary tab)

var WEEKLY_HEADERS = ['User', 'Week Beginning', 'WB JC', 'WB AHT (s)', 'AHT Target (s)', 'If Met', 'Days'];

// ── Sheet helpers ──────────────────────────────────────────────

// Moves a sheet to a specific 1-indexed tab position, if it isn't there
// already. Cheap to call every time since it's a no-op when already correct.
function ensureSheetPosition(sheet, position) {
  if (!sheet) throw new Error('ensureSheetPosition called with no sheet (position ' + position + ')');
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var totalSheets = ss.getSheets().length;
  var safePosition = Math.min(position, totalSheets); // can't move to position 2 if only 1 sheet exists
  if (sheet.getIndex() !== safePosition) {
    ss.setActiveSheet(sheet);
    ss.moveActiveSheet(safePosition);
  }
}

var ENTRIES_HEADERS = ['Backed up at', 'User', 'WB', 'Date', '1st Brk JC', 'Lunch JC', '2nd Brk JC', 'EOS JC', 'Total JC', 'Prod (s)', 'Avg AHT (s)', 'Target', 'Allow.', 'Status', 'Offlines', 'Locked'];

// Applies table-style formatting to a sheet: bold + background header row,
// banded alternating row colours, frozen header, and auto-resized columns.
function applyTableFormatting(sheet, numCols) {
  // Bold header with dark background + white text
  var header = sheet.getRange(1, 1, 1, numCols);
  header.setFontWeight('bold')
        .setBackground('#1a1a2e')
        .setFontColor('#ffffff')
        .setHorizontalAlignment('center');

  // Apply banded rows (alternating colours) to give it a real table look
  var existingBands = sheet.getBandedRanges();
  existingBands.forEach(function(b){ b.remove(); });
  sheet.addBanding(
    sheet.getRange(1, 1, sheet.getMaxRows(), numCols),
    SpreadsheetApp.BandingTheme.LIGHT_GREY
  );

  // Auto-resize all columns so content isn't truncated
  for (var i = 1; i <= numCols; i++) {
    sheet.autoResizeColumn(i);
  }
}

// Returns the Entries sheet, recreating it with headers if it was deleted.
// Never falls back to reusing the Weekly sheet — if Entries is missing,
// a brand new "Entries" tab is created instead, so the two tabs can never
// collide into one.
function getEntriesSheet() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = findSheetByTrimmedName(ss, ENTRIES_SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(ENTRIES_SHEET_NAME);
    sheet.getRange(1, 1, 1, ENTRIES_HEADERS.length).setValues([ENTRIES_HEADERS]);
    sheet.setFrozenRows(1);
    applyTableFormatting(sheet, ENTRIES_HEADERS.length);
  }
  ensureSheetPosition(sheet, 2);
  return sheet;
}

function getWeeklySheet() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = findSheetByTrimmedName(ss, WEEKLY_SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(WEEKLY_SHEET_NAME);
    sheet.getRange(1, 1, 1, WEEKLY_HEADERS.length).setValues([WEEKLY_HEADERS]);
    sheet.setFrozenRows(1);
    applyTableFormatting(sheet, WEEKLY_HEADERS.length);
  } else {
    ensureWeeklyDaysColumn_(sheet);
  }
  ensureSheetPosition(sheet, 1);
  return sheet;
}

// Migration: adds "Days" header in column G for existing Weekly Summary sheets
// created before this column existed. Existing rows get a blank that fills in
// next time that week's summary is written (i.e. next time a day is locked).
function ensureWeeklyDaysColumn_(sheet) {
  // Rename old "Running JC" / "Running AHT" headers to new WB-scoped names
  var h3 = sheet.getRange(1, 3); if (normalizeKey(String(h3.getValue()||'')) === 'runningjc') { h3.setValue('WB JC'); }
  var h4 = sheet.getRange(1, 4); if (normalizeKey(String(h4.getValue()||'')).indexOf('runningaht') === 0) { h4.setValue('WB AHT (s)'); }
  // Add Days column if missing
  var headerCell = sheet.getRange(1, WEEKLY_DAYS_COL);
  if (normalizeKey(String(headerCell.getValue() || '')) === 'days') return;
  headerCell.setValue('Days');
  headerCell.setFontWeight('bold').setBackground('#1a1a2e').setFontColor('#ffffff').setHorizontalAlignment('center');
}

// Case/whitespace-insensitive sheet lookup, so minor naming mismatches
// ("Entries " vs "Entries", "weekly running summary" vs "Weekly Running
// Summary") still resolve to the existing tab instead of spawning a new one.
function findSheetByTrimmedName(ss, name) {
  var target = name.trim().toLowerCase();
  var sheets = ss.getSheets();
  for (var i = 0; i < sheets.length; i++) {
    if (sheets[i].getName().trim().toLowerCase() === target) return sheets[i];
  }
  return null;
}

// ── Shared key normalization ───────────────────────────────────

// Normalizes a cell/payload value for comparison: strips whitespace, and if
// Sheets already converted a date string into a real Date object on an
// older row, reformat it back to YYYY-MM-DD so it still matches.
function normalizeKey(val) {
  if (val instanceof Date) {
    var y = val.getFullYear();
    var m = ('0' + (val.getMonth() + 1)).slice(-2);
    var d = ('0' + val.getDate()).slice(-2);
    return y + '-' + m + '-' + d;
  }
  return String(val || '').trim().replace(/^'/, '');
}

// Finds the 1-indexed row for a given user+date in any sheet, given which
// columns hold user/date on that sheet.
function findRowIndexIn(sheet, userCol, dateCol, user, date) {
  var lastRow = sheet.getLastRow();
  if (lastRow < HEADER_ROWS + 1) return -1;
  var users = sheet.getRange(HEADER_ROWS + 1, userCol, lastRow - HEADER_ROWS, 1).getValues();
  var dates = sheet.getRange(HEADER_ROWS + 1, dateCol, lastRow - HEADER_ROWS, 1).getValues();
  var targetUser = normalizeKey(user);
  var targetDate = normalizeKey(date);
  for (var i = 0; i < dates.length; i++) {
    if (normalizeKey(dates[i][0]) === targetDate && normalizeKey(users[i][0]) === targetUser) {
      return HEADER_ROWS + 1 + i;
    }
  }
  return -1;
}

function buildRowIndexMapIn(sheet, userCol, dateCol) {
  var map = {};
  var lastRow = sheet.getLastRow();
  if (lastRow < HEADER_ROWS + 1) return map;
  var users = sheet.getRange(HEADER_ROWS + 1, userCol, lastRow - HEADER_ROWS, 1).getValues();
  var dates = sheet.getRange(HEADER_ROWS + 1, dateCol, lastRow - HEADER_ROWS, 1).getValues();
  for (var i = 0; i < dates.length; i++) {
    var key = normalizeKey(users[i][0]) + '||' + normalizeKey(dates[i][0]);
    map[key] = HEADER_ROWS + 1 + i; // last one wins if dupes already exist
  }
  return map;
}

// Sorts all data rows (everything below the header) by the given date
// column, newest first. Called after every write so the most recently
// dated entry/week always ends up visually at the top of the sheet —
// "newest" here means newest Date/Week Start value, not newest "Backed up
// at" timestamp, so re-saving an old day doesn't bump it above newer ones.
function sortSheetByDateDesc(sheet, dateCol) {
  var lastRow = sheet.getLastRow();
  var lastCol = sheet.getLastColumn();
  if (lastRow <= HEADER_ROWS) return; // nothing to sort
  var range = sheet.getRange(HEADER_ROWS + 1, 1, lastRow - HEADER_ROWS, lastCol);
  range.sort({ column: dateCol, ascending: false });
}

// Shared engine: for a given user, finds their most recent "period" value
// (by comparing the given dateCol across their rows) and hides every row
// for that user whose periodCol value differs from it, unhiding the rest.
// Used for both the Entries tab (period = WB) and the Weekly Running
// Summary tab (period = Week Beginning, which doubles as its own date col).
function refreshLatestPeriodVisibilityForUser(sheet, user, userCol, periodCol, dateCol, label) {
  try {
    var lastRow = sheet.getLastRow();
    if (lastRow < HEADER_ROWS + 1) return;

    var numRows = lastRow - HEADER_ROWS;
    var users   = sheet.getRange(HEADER_ROWS + 1, userCol, numRows, 1).getValues();
    var periods = sheet.getRange(HEADER_ROWS + 1, periodCol, numRows, 1).getValues();
    var dates   = sheet.getRange(HEADER_ROWS + 1, dateCol, numRows, 1).getValues();

    var targetUser = normalizeKey(user);
    if (!targetUser) {
      Logger.log('refreshLatestPeriodVisibilityForUser[' + label + ']: empty user, skipping');
      return;
    }

    // Find this user's latest period by comparing date values across their rows.
    var latestPeriod = null;
    var latestDateKey = null;
    for (var i = 0; i < numRows; i++) {
      if (normalizeKey(users[i][0]) !== targetUser) continue;
      var dateKey = normalizeKey(dates[i][0]);
      if (latestDateKey === null || dateKey > latestDateKey) {
        latestDateKey = dateKey;
        latestPeriod = normalizeKey(periods[i][0]);
      }
    }
    if (latestPeriod === null) {
      Logger.log('refreshLatestPeriodVisibilityForUser[' + label + ']: no rows found for user "' + targetUser + '"');
      return;
    }

    // Hide rows for this user whose period isn't the latest one; unhide the rest.
    var hiddenCount = 0, shownCount = 0;
    for (var r = 0; r < numRows; r++) {
      if (normalizeKey(users[r][0]) !== targetUser) continue;
      var rowNum = HEADER_ROWS + 1 + r;
      var rowPeriod = normalizeKey(periods[r][0]);
      if (rowPeriod === latestPeriod) {
        sheet.showRows(rowNum);
        shownCount++;
      } else {
        sheet.hideRows(rowNum);
        hiddenCount++;
      }
    }
    Logger.log('refreshLatestPeriodVisibilityForUser[' + label + ']: user="' + targetUser +
               '" latest="' + latestPeriod + '" shown=' + shownCount + ' hidden=' + hiddenCount);
  } catch (err) {
    // Never let a visibility-refresh failure block the actual data write —
    // log it so it's visible in Executions, but swallow it here.
    Logger.log('refreshLatestPeriodVisibilityForUser[' + label + '] ERROR: ' + err.message);
  }
}

// Entries tab: hides a user's rows from any WB other than their most recent
// one (latest by Date column).
function refreshWbVisibilityForUser(sheet, user) {
  refreshLatestPeriodVisibilityForUser(sheet, user, USER_COL, WB_COL, DATE_COL, 'Entries/WB');
}

// Weekly Running Summary tab: hides a user's rows from any Week Beginning
// other than their most recent one. Week Beginning is itself a sortable
// YYYY-MM-DD-ish string, so it's used as both the period and the date.
function refreshWeeklyVisibilityForUser(sheet, user) {
  refreshLatestPeriodVisibilityForUser(sheet, user, WEEKLY_USER_COL, WEEKLY_DATE_COL, WEEKLY_DATE_COL, 'Weekly');
}

// ── Entries tab ─────────────────────────────────────────────────

function buildEntryRow(data) {
  var ivJC = data.ivJC || ['', '', '', ''];
  return [
    new Date(),                   // Backed up at (timestamp)
    data.user || '',              // User
    data.wb || '',                // WB
    "'" + (data.date || ''),      // Date — leading apostrophe forces plain text
    ivJC[0] || '',                // 1st Brk JC
    ivJC[1] || '',                // Lunch JC
    ivJC[2] || '',                // 2nd Brk JC
    ivJC[3] || '',                // EOS JC
    data.totalJC || '',           // Total JC
    data.prodS || '',             // Prod (s)
    data.avgAHTsec || '',         // Avg AHT (s)
    data.target || '',            // Target
    data.allowance || '',         // Allow.
    data.status || '',            // Status
    data.offlines || '',          // Offlines (offline minutes per interval, that day)
    data.locked ? 'Yes' : ''      // Locked
  ];
}

function upsertEntry(data) {
  var sheet = getEntriesSheet();
  var row = buildEntryRow(data);
  var existingRow = findRowIndexIn(sheet, USER_COL, DATE_COL, data.user || '', data.date || '');
  if (existingRow > 0) {
    sheet.getRange(existingRow, 1, 1, row.length).setValues([row]);
  } else {
    sheet.appendRow(row);
  }
  sortSheetByDateDesc(sheet, DATE_COL);
  refreshWbVisibilityForUser(sheet, data.user || '');
}

function deleteEntry(data) {
  var sheet = getEntriesSheet();
  var existingRow = findRowIndexIn(sheet, USER_COL, DATE_COL, data.user || '', data.date || '');
  if (existingRow > 0) sheet.deleteRow(existingRow);
  // No re-sort needed after a delete — removing a row doesn't change the
  // relative order of everything else. Still refresh WB visibility though:
  // deleting the user's only row for the latest WB should reveal whatever
  // WB is now the most recent one for them.
  refreshWbVisibilityForUser(sheet, data.user || '');
}

function upsertEntryBatch(items) {
  var sheet = getEntriesSheet();
  var rowMap = buildRowIndexMapIn(sheet, USER_COL, DATE_COL);
  var toAppend = [];
  var pendingNewKeys = {};

  items.forEach(function (data) {
    var key = normalizeKey(data.user || '') + '||' + normalizeKey(data.date || '');
    var row = buildEntryRow(data);
    if (rowMap[key]) {
      sheet.getRange(rowMap[key], 1, 1, row.length).setValues([row]);
    } else if (pendingNewKeys.hasOwnProperty(key)) {
      toAppend[pendingNewKeys[key]] = row;
    } else {
      pendingNewKeys[key] = toAppend.length;
      toAppend.push(row);
    }
  });

  if (toAppend.length > 0) {
    sheet.getRange(sheet.getLastRow() + 1, 1, toAppend.length, toAppend[0].length).setValues(toAppend);
  }
  sortSheetByDateDesc(sheet, DATE_COL);

  // Refresh WB visibility once per distinct user touched by this batch, so
  // any user who just got a new WB has their previous-WB rows hidden.
  var touchedUsers = {};
  items.forEach(function (data) {
    touchedUsers[normalizeKey(data.user || '')] = data.user || '';
  });
  Object.keys(touchedUsers).forEach(function (key) {
    refreshWbVisibilityForUser(sheet, touchedUsers[key]);
  });
}

// ── Weekly Running Summary tab ─────────────────────────────────
// Work week = Saturday through Friday. Each row is one user's totals for
// one work week, keyed by user+weekStart so re-locking any day within that
// week overwrites the same row instead of creating a new one.

function buildWeeklyRow(data) {
  var jc = parseNum(data.totalJC);
  var aht = parseNum(data.weeklyAHT);
  var tgt = parseNum(data.target);
  var ifMet = (jc > 0 && tgt > 0) ? (aht <= tgt ? 'Yes' : 'No') : '';
  // "Days" column: e.g. "2/5" — locked days out of 5 expected work days per week.
  // daysLocked = how many days the user has saved-and-locked that week.
  // We always show /5 since a standard work week is 5 days (Sat–Fri in this app).
  var daysLocked = parseNum(data.daysLocked) || 0;
  var daysDisplay = daysLocked + '/5';
  return [
    data.user || '',               // User
    "'" + (data.weekStart || ''),  // Week Beginning
    jc,                            // Running JC
    aht,                           // Running AHT (s)
    tgt,                           // AHT Target (s)
    ifMet,                         // If Met
    daysDisplay                    // Days (e.g. "2/5")
  ];
}

// Pulls a leading number out of a formatted display string like "17.30s" or
// "23" — some fields may arrive as already-formatted text rather than raw
// numbers, so this recovers a usable number either way.
function parseNum(val) {
  if (typeof val === 'number') return val;
  var match = String(val || '').match(/-?\d+(\.\d+)?/);
  return match ? parseFloat(match[0]) : 0;
}

// Column D ("Running AHT (s)") index on the Weekly Running Summary tab.
var WEEKLY_AHT_COL = 4;
// Column F ("If Met") index on the Weekly Running Summary tab.
var WEEKLY_IFMET_COL = 6;
// Column G ("Days") index on the Weekly Running Summary tab.
var WEEKLY_DAYS_COL = 7;

// (Re)applies conditional formatting to just the "Running AHT (s)" cell of
// each row on the Weekly Running Summary sheet: green if that row's "If Met"
// says "Yes" (running AHT meets target), red if "No". Only the AHT cell
// itself is shaded — not the whole row. The rule is formula-driven off
// column F so it keeps following the right row even after re-sorting. Safe
// to call repeatedly — it always replaces any prior rules rather than
// stacking them.
function applyWeeklyConditionalFormatting(sheet) {
  var maxRows = sheet.getMaxRows();
  if (maxRows <= HEADER_ROWS) return;

  var ahtRange = sheet.getRange(HEADER_ROWS + 1, WEEKLY_AHT_COL, maxRows - HEADER_ROWS, 1);
  var ifMetColLetter = sheet.getRange(1, WEEKLY_IFMET_COL).getA1Notation().replace(/\d+$/, '');

  var metRule = SpreadsheetApp.newConditionalFormatRule()
    .whenFormulaSatisfied('=$' + ifMetColLetter + (HEADER_ROWS + 1) + '="Yes"')
    .setBackground('#d9ead3') // light green
    .setRanges([ahtRange])
    .build();

  var notMetRule = SpreadsheetApp.newConditionalFormatRule()
    .whenFormulaSatisfied('=$' + ifMetColLetter + (HEADER_ROWS + 1) + '="No"')
    .setBackground('#f4cccc') // light red
    .setRanges([ahtRange])
    .build();

  sheet.setConditionalFormatRules([metRule, notMetRule]);
}

function upsertWeekly(data) {
  var sheet = getWeeklySheet();
  var row = buildWeeklyRow(data);
  var existingRow = findRowIndexIn(sheet, WEEKLY_USER_COL, WEEKLY_DATE_COL, data.user || '', data.weekStart || '');
  if (existingRow > 0) {
    sheet.getRange(existingRow, 1, 1, row.length).setValues([row]);
  } else {
    sheet.appendRow(row);
  }
  sortSheetByDateDesc(sheet, WEEKLY_DATE_COL);
  applyWeeklyConditionalFormatting(sheet);
  refreshWeeklyVisibilityForUser(sheet, data.user || '');
}

function upsertWeeklyBatch(items) {
  var sheet = getWeeklySheet();
  var rowMap = buildRowIndexMapIn(sheet, WEEKLY_USER_COL, WEEKLY_DATE_COL);
  var toAppend = [];
  var pendingNewKeys = {};

  items.forEach(function (data) {
    var key = normalizeKey(data.user || '') + '||' + normalizeKey(data.weekStart || '');
    var row = buildWeeklyRow(data);
    if (rowMap[key]) {
      sheet.getRange(rowMap[key], 1, 1, row.length).setValues([row]);
    } else if (pendingNewKeys.hasOwnProperty(key)) {
      toAppend[pendingNewKeys[key]] = row;
    } else {
      pendingNewKeys[key] = toAppend.length;
      toAppend.push(row);
    }
  });

  if (toAppend.length > 0) {
    sheet.getRange(sheet.getLastRow() + 1, 1, toAppend.length, toAppend[0].length).setValues(toAppend);
  }
  sortSheetByDateDesc(sheet, WEEKLY_DATE_COL);
  applyWeeklyConditionalFormatting(sheet);

  // Refresh Week Beginning visibility once per distinct user touched by this
  // batch, so any user who just got a new current week has their previous
  // weeks hidden.
  var touchedWeeklyUsers = {};
  items.forEach(function (data) {
    touchedWeeklyUsers[normalizeKey(data.user || '')] = data.user || '';
  });
  Object.keys(touchedWeeklyUsers).forEach(function (key) {
    refreshWeeklyVisibilityForUser(sheet, touchedWeeklyUsers[key]);
  });
}

// Reads a user's entries from the Entries sheet using the existing display
// columns — works even on old backups that have no RawData column.
// Returns an array of lightweight entry objects the frontend can merge in.
// Column map (1-indexed): B=User, C=WB, D=Date, E=1stBrkJC, F=LunchJC,
// G=2ndBrkJC, H=EOSJC, I=TotalJC, J=Prod(s), K=AvgAHT, L=Target,
// M=Allow, N=Status, O=Offlines, P=Locked
function getEntriesByUser(user) {
  user = (user || '').trim();
  if (!user) throw new Error('Name is required.');

  var sheet = getEntriesSheet();
  var lastRow = sheet.getLastRow();
  if (lastRow <= HEADER_ROWS) return { user: user, entries: [] };

  var numRows = lastRow - HEADER_ROWS;
  // Read columns B through P (cols 2–16) in one batch call — 15 columns wide
  var data = sheet.getRange(HEADER_ROWS + 1, 2, numRows, 15).getValues();
  // Col offsets within that range (0-indexed):
  // 0=User, 1=WB, 2=Date, 3=1stBrkJC, 4=LunchJC, 5=2ndBrkJC, 6=EOSJC,
  // 7=TotalJC, 8=Prod(s), 9=AvgAHT, 10=Target, 11=Allow, 12=Status,
  // 13=Offlines, 14=Locked

  var targetUser = normalizeKey(user);
  var entries = [];
  var IVS = ['1st Break', 'Lunch', '2nd Break', 'EOS'];
  var IV_DEF_S = { '1st Break': 7200, 'Lunch': 6300, '2nd Break': 7200, 'EOS': 6300 };

  data.forEach(function(row) {
    if (normalizeKey(String(row[0] || '')) !== targetUser) return;

    var rawDate = String(row[2] || '').trim().replace(/^'/, '');
    if (!/^\d{4}-\d{2}-\d{2}/.test(rawDate)) return;
    var dateStr = rawDate.substring(0, 10);

    var wb     = String(row[1] || '').replace(/^'/, '').trim();
    var status = String(row[12] || '').trim();
    var locked = String(row[14] || '').trim().toLowerCase() === 'yes';
    var isRestDay = /rest\s*day/i.test(status);

    // Parse the Offlines cell. Two formats:
    // NEW (named):   "1st Break:100.0min | EOS:105.0min"  — exact per-interval
    // OLD (unnamed): "100.0min | 105.0min"                — pipe segments in
    //   order of intervals that had offline > 0, but we don't know which ones.
    //   Best effort: assign segments in order to intervals that have JC > 0,
    //   since offline only happens in intervals where the agent was clocked in.
    var offlineMinPerIV = { '1st Break':0, 'Lunch':0, '2nd Break':0, 'EOS':0 };
    var offlineRaw = String(row[13] || '').trim();
    var jcValsForOffline = [
      parseInt(row[3]) || 0,
      parseInt(row[4]) || 0,
      parseInt(row[5]) || 0,
      parseInt(row[6]) || 0
    ];
    if (offlineRaw) {
      var parts = offlineRaw.split('|').map(function(s){ return s.trim(); }).filter(Boolean);
      var isNamed = parts.some(function(p){
        return /^(1st Break|Lunch|2nd Break|EOS)\s*:/i.test(p);
      });
      if (isNamed) {
        // Named format: "1st Break:Coaching 1 — 30.0min" or "1st Break:30.0min"
        // Try explicit "min" unit first; fall back to preset label lookup.
        parts.forEach(function(part){
          var nameMatch = part.match(/^(1st Break|Lunch|2nd Break|EOS)\s*:/i);
          if (!nameMatch) return;
          var ivKey = IVS.filter(function(k){
            return k.toLowerCase() === nameMatch[1].toLowerCase();
          })[0];
          if (!ivKey) return;
          var minMatch = part.match(/(\d+(\.\d+)?)\s*min/i);
          if (minMatch) {
            offlineMinPerIV[ivKey] = parseFloat(minMatch[1]) || 0;
          } else {
            // No explicit minutes — try resolving each label via preset table
            var labelPart = part.replace(/^(1st Break|Lunch|2nd Break|EOS)\s*:/i, '').trim();
            var total = 0;
            labelPart.split(/\s*\+\s*/).forEach(function(lbl){
              total += PRESET_MINS[lbl.trim().toLowerCase()] || 0;
            });
            if (total > 0) offlineMinPerIV[ivKey] = total;
          }
        });
      } else {
        // Old unnamed format: "100.0min | 105.0min" or "Coaching 1 | Coaching 2"
        // Try explicit min unit first; fall back to preset label lookup.
        var activeIVS = IVS.filter(function(ivName, i){ return jcValsForOffline[i] > 0; });
        parts.forEach(function(part, i){
          if (i >= activeIVS.length) return;
          var minMatch = part.match(/(\d+(\.\d+)?)\s*min/i);
          if (minMatch) {
            offlineMinPerIV[activeIVS[i]] = parseFloat(minMatch[1]) || 0;
          } else {
            var total = 0;
            part.split(/\s*\+\s*/).forEach(function(lbl){
              total += PRESET_MINS[lbl.trim().toLowerCase()] || 0;
            });
            if (total > 0) offlineMinPerIV[activeIVS[i]] = total;
          }
        });
      }
    }

    var iv = {};
    if (!isRestDay) {
      var jcVals = [
        parseInt(row[3]) || 0,
        parseInt(row[4]) || 0,
        parseInt(row[5]) || 0,
        parseInt(row[6]) || 0
      ];
      IVS.forEach(function(ivName, i) {
        var offMin = offlineMinPerIV[ivName] || 0;
        var offS   = Math.round(offMin * 60);
        iv[ivName] = {
          jc:         jcVals[i],
          totalS:     IV_DEF_S[ivName],
          offlineS:   offS,
          totalMin:   IV_DEF_S[ivName] / 60,
          offlineMin: offMin
        };
      });
    }

    entries.push({
      id:        Date.now() + Math.random(),
      date:      dateStr,
      wb:        wb,
      isRestDay: isRestDay,
      locked:    locked,
      iv:        iv
    });
  });

  return { user: user, entries: entries };
}

// Offline preset label → minutes lookup. Must stay in sync with OFFLINE_OPTS
// in index.html. Used to recover minutes from old-format backup rows that
// stored only the label name (e.g. "Coaching 1") without an explicit minute value.
var PRESET_MINS = {
  'meeting': 25,
  'daily stand up': 15,
  'coaching 1': 30,
  'coaching 2': 45,
  'upskill': 90,
  'team huddle': 20,
  'system issue': 10,
  'vto 60': 60,
  'vto 30': 30,
  'vto 15': 15,
  '5 min': 5,
  '1 min': 1
};

// Manager password — change this to whatever you want.
// Keep it here in the .gs file; it never appears in the HTML.
var MANAGER_PASSWORD = 'Manager2026';

// Verifies the manager password. Returns ok if it matches.
function managerAuth(data) {
  if (!data.password || data.password !== MANAGER_PASSWORD) {
    throw new Error('Incorrect manager password.');
  }
  return { ok: true };
}

// Returns a full team summary: one object per user containing their entries
// for the current WB only (the visible/active week), plus their all-time
// entry list for drill-down. Used by the Manager view in the app.
function getTeamSummary() {
  var entriesSheet = getEntriesSheet();
  var lastRow = entriesSheet.getLastRow();
  if (lastRow <= HEADER_ROWS) return { users: [] };

  var numRows = lastRow - HEADER_ROWS;
  var data = entriesSheet.getRange(HEADER_ROWS + 1, 2, numRows, 15).getValues();

  var IVS_LOCAL = ['1st Break', 'Lunch', '2nd Break', 'EOS'];
  var IV_DEF_S  = { '1st Break': 7200, 'Lunch': 6300, '2nd Break': 7200, 'EOS': 6300 };

  // Group all entries by user
  var userMap = {};
  data.forEach(function(row) {
    var user = String(row[0] || '').trim();
    if (!user) return;

    var rawDate = String(row[2] || '').trim().replace(/^'/, '');
    if (!/^\d{4}-\d{2}-\d{2}/.test(rawDate)) return;
    var dateStr = rawDate.substring(0, 10);

    var wb      = String(row[1] || '').replace(/^'/, '').trim();
    var status  = String(row[12] || '').trim();
    var locked  = String(row[14] || '').trim().toLowerCase() === 'yes';
    var isRest  = /rest\s*day/i.test(status);
    var totalJC = parseInt(row[7]) || 0;
    var prodS   = parseFloat(String(row[8] || '').replace(/[^0-9.]/g, '')) || 0;
    var avgAHT  = parseFloat(String(row[9] || '').replace(/[^0-9.]/g, '')) || 0;
    var target  = parseFloat(String(row[10] || '').replace(/[^0-9.]/g, '')) || 17;

    // Parse offline
    var offlineMinPerIV = { '1st Break':0,'Lunch':0,'2nd Break':0,'EOS':0 };
    var offlineRaw = String(row[13] || '').trim();
    var jcVals = [parseInt(row[3])||0,parseInt(row[4])||0,parseInt(row[5])||0,parseInt(row[6])||0];
    if (offlineRaw) {
      var parts = offlineRaw.split('|').map(function(s){ return s.trim(); }).filter(Boolean);
      var isNamed = parts.some(function(p){ return /^(1st Break|Lunch|2nd Break|EOS)\s*:/i.test(p); });
      if (isNamed) {
        parts.forEach(function(part){
          var nm = part.match(/^(1st Break|Lunch|2nd Break|EOS)\s*:/i); if (!nm) return;
          var ivKey = IVS_LOCAL.filter(function(k){ return k.toLowerCase()===nm[1].toLowerCase(); })[0];
          if (!ivKey) return;
          var mm = part.match(/(\d+(\.\d+)?)\s*min/i);
          if (mm) offlineMinPerIV[ivKey] = parseFloat(mm[1]) || 0;
          else {
            var lbl = part.replace(/^(1st Break|Lunch|2nd Break|EOS)\s*:/i,'').trim();
            var tot=0; lbl.split(/\s*\+\s*/).forEach(function(l){ tot+=PRESET_MINS[l.trim().toLowerCase()]||0; });
            if(tot>0) offlineMinPerIV[ivKey]=tot;
          }
        });
      } else {
        var actIVS=IVS_LOCAL.filter(function(n,i){ return jcVals[i]>0; });
        parts.forEach(function(part,i){
          if(i>=actIVS.length) return;
          var mm=part.match(/(\d+(\.\d+)?)\s*min/i);
          if(mm){ offlineMinPerIV[actIVS[i]]=parseFloat(mm[1])||0; }
          else { var tot=0; part.split(/\s*\+\s*/).forEach(function(l){ tot+=PRESET_MINS[l.trim().toLowerCase()]||0; }); if(tot>0) offlineMinPerIV[actIVS[i]]=tot; }
        });
      }
    }

    var iv = {};
    if (!isRest) {
      IVS_LOCAL.forEach(function(ivName, i) {
        var offMin = offlineMinPerIV[ivName] || 0;
        iv[ivName] = { jc: jcVals[i], totalS: IV_DEF_S[ivName], offlineS: Math.round(offMin*60), totalMin: IV_DEF_S[ivName]/60, offlineMin: offMin };
      });
    }

    if (!userMap[user]) userMap[user] = { name: user, entries: [] };
    userMap[user].entries.push({
      id: Date.now() + Math.random(),
      date: dateStr, wb: wb, isRestDay: isRest,
      locked: locked, iv: iv,
      totalJC: totalJC, prodS: prodS, avgAHT: avgAHT, target: target, status: status
    });
  });

  // For each user compute current-WB summary
  var users = Object.keys(userMap).map(function(name) {
    var u = userMap[name];
    var entries = u.entries;

    // Find their latest WB
    var latestWB = '';
    entries.forEach(function(e){ if(e.wb > latestWB) latestWB = e.wb; });

    // Current WB entries only (non-rest, non-full-leave)
    var wbEntries = entries.filter(function(e){
      return e.wb === latestWB && !e.isRestDay;
    });

    var wbJC   = wbEntries.reduce(function(s,e){ return s+(e.totalJC||0); }, 0);
    var wbProd = wbEntries.reduce(function(s,e){ return s+(e.prodS||0); }, 0);
    var wbAHT  = wbJC > 0 ? (wbProd / wbJC) : 0;
    var target = wbEntries.length ? (wbEntries[wbEntries.length-1].target || 17) : 17;
    var locked = wbEntries.filter(function(e){ return e.locked; }).length;
    var metDays = wbEntries.filter(function(e){ return /^met$/i.test((e.status||'').trim()); }).length;

    return {
      name: name,
      wb: latestWB,
      wbJC: wbJC,
      wbAHT: Math.round(wbAHT * 100) / 100,
      target: target,
      metDays: metDays,
      lockedDays: locked,
      totalDays: wbEntries.length,
      ifMet: wbJC > 0 ? (wbAHT <= target ? 'Met' : 'Not Met') : '—',
      entries: entries   // full history for drill-down
    };
  });

  return { users: users };
}

// ── Entry points ────────────────────────────────────────────────

function doPost(e) {
  try {
    var data = JSON.parse(e.postData.contents);
    var branch, sheetName, result;

    if (data.action === 'managerAuth') {
      result = managerAuth(data);
      return ContentService.createTextOutput(JSON.stringify({ status: 'ok', branch: 'managerAuth', result: result }))
        .setMimeType(ContentService.MimeType.JSON);
    } else if (data.action === 'getTeamSummary') {
      result = getTeamSummary();
      return ContentService.createTextOutput(JSON.stringify({ status: 'ok', branch: 'getTeamSummary', result: result }))
        .setMimeType(ContentService.MimeType.JSON);
    } else if (data.action === 'getEntriesByUser') {
      result = getEntriesByUser(data.user);
      return ContentService.createTextOutput(JSON.stringify({ status: 'ok', branch: 'getEntriesByUser', result: result }))
        .setMimeType(ContentService.MimeType.JSON);
    } else if (data.batch && Array.isArray(data.batch)) {
      branch = 'entryBatch';
      upsertEntryBatch(data.batch);
      sheetName = getEntriesSheet().getName();
    } else if (data.weeklyBatch && Array.isArray(data.weeklyBatch)) {
      branch = 'weeklyBatch';
      upsertWeeklyBatch(data.weeklyBatch);
      sheetName = getWeeklySheet().getName();
    } else if (data.weeklySummary) {
      branch = 'weeklySummary';
      upsertWeekly(data);
      sheetName = getWeeklySheet().getName();
    } else if (data.action === 'delete') {
      branch = 'delete';
      deleteEntry(data);
      sheetName = getEntriesSheet().getName();
    } else {
      branch = 'entry';
      upsertEntry(data);
      sheetName = getEntriesSheet().getName();
    }

    return ContentService.createTextOutput(JSON.stringify({ status: 'ok', branch: branch, sheet: sheetName }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ status: 'error', message: err.message }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet(e) {
  return ContentService.createTextOutput(JSON.stringify({ status: 'AHT backup endpoint is live' }))
    .setMimeType(ContentService.MimeType.JSON);
}

// ── Manual diagnostics ──────────────────────────────────────────
// Run this directly from the Apps Script editor (select it in the function
// dropdown, click Run) to re-apply WB auto-hide for every user currently on
// the Entries sheet, without needing a web request. Check View > Logs (or
// View > Executions) afterward to see exactly what it found per user — this
// is the fastest way to confirm whether the logic itself works against your
// real data, independent of whatever the frontend is sending.
function debugRefreshAllWbVisibility() {
  var sheet = getEntriesSheet();
  var lastRow = sheet.getLastRow();
  if (lastRow < HEADER_ROWS + 1) {
    Logger.log('No data rows found.');
    return;
  }
  var numRows = lastRow - HEADER_ROWS;
  var users = sheet.getRange(HEADER_ROWS + 1, USER_COL, numRows, 1).getValues();

  var seen = {};
  for (var i = 0; i < numRows; i++) {
    var u = normalizeKey(users[i][0]);
    if (!u || seen[u]) continue;
    seen[u] = true;
    Logger.log('--- Refreshing for user: ' + u + ' ---');
    refreshWbVisibilityForUser(sheet, u);
  }
  Logger.log('Done. ' + Object.keys(seen).length + ' distinct user(s) processed.');
}

// Same idea as debugRefreshAllWbVisibility, but for the Weekly Running
// Summary tab: re-applies the "only latest Week Beginning visible per user"
// rule for every user currently on that sheet.
function debugRefreshAllWeeklyVisibility() {
  var sheet = getWeeklySheet();
  var lastRow = sheet.getLastRow();
  if (lastRow < HEADER_ROWS + 1) {
    Logger.log('No data rows found.');
    return;
  }
  var numRows = lastRow - HEADER_ROWS;
  var users = sheet.getRange(HEADER_ROWS + 1, WEEKLY_USER_COL, numRows, 1).getValues();

  var seen = {};
  for (var i = 0; i < numRows; i++) {
    var u = normalizeKey(users[i][0]);
    if (!u || seen[u]) continue;
    seen[u] = true;
    Logger.log('--- Refreshing weekly visibility for user: ' + u + ' ---');
    refreshWeeklyVisibilityForUser(sheet, u);
  }
  Logger.log('Done. ' + Object.keys(seen).length + ' distinct user(s) processed.');
}
